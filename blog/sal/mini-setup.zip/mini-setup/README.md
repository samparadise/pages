# mini-setup: build your own assistant on a Mac mini

A Claude Code skill that walks you, step by step, from an empty Mac to a personal assistant you
text from your phone (Telegram), with an Obsidian "brain" it learns into, scheduled tasks, and
optional browser, TripIt and remote access.

## Start

1. On the Mac that will run it, install Claude Code and sign in:
   `curl -fsSL https://claude.ai/install.sh | bash`, then run `claude` once and log in.
   (You need a Claude Pro or Max plan.)
2. Unzip `mini-setup.zip` and move the whole `mini-setup` folder to
   `~/.claude/skills/mini-setup/` on that Mac. In Terminal:
   `mkdir -p ~/.claude/skills && mv ~/Downloads/mini-setup ~/.claude/skills/`
3. In Terminal, run `claude` and say: **"Set up my assistant."**

It asks what you want first (what areas of your life, which connections), then takes you
through each step, does the terminal work itself, and tells you exactly what to click for the
parts only you can do. Progress is saved in `~/assistant/SETUP.md`, so you can stop and pick it
up later by saying "continue my assistant setup".

## What's inside

- `SKILL.md`: the walkthrough Claude follows
- `templates/`: the bot, task runner, launchd jobs, browser connector, a starter `CLAUDE.md`,
  permissions, starter skills and an empty brain. Nothing personal; placeholders like
  `{{OWNER}}` are filled in during setup.
