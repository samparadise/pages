#!/bin/zsh
# Opens Chrome with the assistant's browser profile so the owner can sign in to sites once.
# Usage: sign-in-browser.sh [url ...]   (defaults to the OpenTable and Resy sign-in pages)
# --use-mock-keychain matches how Playwright launches Chrome; without it the saved logins are
# encrypted with a key Playwright can't read, and the assistant looks signed out.
# Quit it (Cmd-Q) before the assistant uses the browser again: one profile, one Chrome.
(( $# )) || set -- https://www.opentable.com/signin https://resy.com
exec "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  --user-data-dir={{HOME}}/mcp/browser-profile --use-mock-keychain "$@"
