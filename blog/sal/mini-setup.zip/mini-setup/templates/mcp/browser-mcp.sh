#!/bin/zsh
# Playwright MCP for the assistant: real Chrome, visible on the mini's screen, with its own
# persistent profile (the owner signs in to sites here once with sign-in-browser.sh).
exec /opt/homebrew/bin/node {{HOME}}/mcp/playwright/node_modules/@playwright/mcp/cli.js \
  --browser chrome \
  --user-data-dir {{HOME}}/mcp/browser-profile \
  --output-dir {{HOME}}/mcp/browser-output \
  --viewport-size 1280,900 "$@"
