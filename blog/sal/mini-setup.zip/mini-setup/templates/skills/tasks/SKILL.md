---
name: tasks
description: Manages {{OWNER}}'s recurring background tasks in ~/assistant/scripts/tasks.json. Use whenever they want anything recurring, scheduled or ongoing ("check every Friday", "notify me when", "keep looking for", "every morning send me") or to change, pause, resume, stop or list tasks. Do NOT use built-in scheduling tools; write to tasks.json instead.
---

The task runner checks this queue every 15 minutes, runs what's due through Claude, and sends a
Telegram message when a run has something worth reporting. Put a task's rules in the matching
skill and keep the prompt to what's specific to the task.

## Task file

`~/assistant/scripts/tasks.json`:

```json
{
  "tasks": [
    {
      "id": "short-kebab-slug",
      "description": "One-liner shown in /status",
      "agent": "eats",
      "prompt": "Full prompt for each run, with every criterion given. Ends with the signal instruction.",
      "interval_minutes": 720,
      "run_on": null,
      "run_at": null,
      "status": "active",
      "created": "2026-01-01T00:00:00"
    }
  ]
}
```

- `agent`: the skill the task starts from. The runner sends `<agent>: <prompt>`.
- `run_on`: lowercase weekday (`"friday"`) or null. `run_at`: local `"HH:MM"` or null. When
  either is set, `interval_minutes` is null.
- `status`: `active`, `paused` or `done`. Never delete entries.
- Last run times are in `~/assistant/scripts/task_state.json`. Read it; never write it.

| They say | interval_minutes | run_on | run_at |
|---|---|---|---|
| "every Friday morning" | null | "friday" | "08:00" |
| "every morning at 7" | null | null | "07:00" |
| "daily" | 1440 | null | null |
| "twice a day" / unspecified | 720 | null | null |
| "every hour" | 60 | null | null |
| "weekly" | 10080 | null | null |

When in doubt, run less often. "Morning" with no time means 08:00.

## Signal instruction (end every prompt with this)

```
Respond with one of three formats only:
- NOTIFY: [your message] — if you found something worth telling {{OWNER}}
- QUIET — if nothing new to report
- STOP: [reason] — if this task is no longer relevant (the event passed, the criteria can never be met)
Do not include any other text outside these formats.
```

NOTIFY text is sent as-is: start with the update itself, no task label. Every sent message is
saved by the runner to `~/Documents/brain/wiki/personal/task-messages.md`; task runs are
separate sessions, so read that page when {{OWNER}} replies to a check-in.

## Operations

- **Create**: read the file, pick the skill and schedule yourself, write the entry, then confirm
  what it does and when it runs, in plain English.
- **Change**: match the task fuzzily on description or id, change only what's needed, keep the
  signal instruction, confirm.
- **Pause / resume**: `status: paused` / `active`. If unclear whether they mean pause or stop,
  pause.
- **Stop**: `status: done`.
- **List**: active tasks (description, schedule in plain English, last run), then paused ones.

Then commit `../scripts/tasks.json` as CLAUDE.md describes.
