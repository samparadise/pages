---
name: brain
description: {{OWNER}}'s second brain, the Obsidian wiki in ~/Documents/brain. Use for any "remember this", memory question ("what do I know about…"), wiki update or correction, and whenever another skill saves something to the brain.
---

The brain is the assistant's only memory. Read `~/Documents/brain/BRAIN_SCHEMA.md` for the page
conventions before writing.

## Reading

1. Start at `index.md`, which lists every page with a one-line description.
2. Open the pages that could change the answer: `wiki/personal/assistant-preferences.md`
   always, the area's preferences page, the people involved, past logs.
3. If nothing's there, say so plainly rather than guessing.

## Writing

- **Update before you create.** Fold new facts into the existing page; create a page only for a
  genuinely new person, place, area or topic.
- **The latest word wins.** Replace what's superseded, and add a dated line under the page's
  `## Change log` (`- YYYY-MM-DD: what changed`).
- Every new page gets a line in `index.md` and at least one `[[link]]` to a related page.
- Append an entry to `log.md` for every change:
  `## [YYYY-MM-DD | update] Page title` and one line on what changed.
- Places: one page per place under `wiki/places/<city>/<slug>.md`, with what {{OWNER}} thought
  of it. People: `wiki/people/<first-last>.md`.
- Don't save search results or options {{OWNER}} didn't react to.

## Where things go

| What | Page |
|---|---|
| How {{OWNER}} wants you to work | `wiki/personal/assistant-preferences.md` |
| Who they are, base facts | `wiki/personal/profile.md` |
| Likes and dislikes in an area | `wiki/<area>/<area>-preferences.md` |
| A person | `wiki/people/<name>.md` |
| A place | `wiki/places/<city>/<slug>.md` |
| Lists | `wiki/lists/<slug>.md` (checkboxes) |
| Messages scheduled tasks sent | `wiki/personal/task-messages.md` (written by the runner; read-only for you) |
