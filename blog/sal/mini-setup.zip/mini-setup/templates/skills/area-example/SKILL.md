---
name: eats
description: Food and drink. Use for any restaurant, bar, coffee, happy hour, dining or drinks question, including search, comparison, live availability and booking.
---

<!-- Template for an area skill. Copy to skills/<short-name>/SKILL.md, rename, and rewrite the
     description (it decides when Claude uses this skill) and the sections below. Keep it
     short: mechanics here, preferences in the brain. -->

## Before answering

1. Read `wiki/dining/dining-preferences.md` and any place pages for the city in question.
2. Check TripIt and the calendar: which city {{OWNER}} is in on that date, and who's coming.
3. Check live data: current hours, and real availability in the browser before recommending a
   time.

## Recommending

- Give two or three options, best first, each with one line on why it fits what they like.
- Say what you assumed (city, date, party size) in one line.
- Never recommend a place you haven't confirmed is open.

## Booking

Follow "Ask before anything irreversible" in CLAUDE.md: show the exact booking (place, date,
time, party size, any card hold or cancellation fee) and wait for a yes. After booking, send the
confirmation and file it in `wiki/dining/reservations.md`.

## Where records go

- Preferences: `wiki/dining/dining-preferences.md`
- A place they've been or reacted to: `wiki/places/<city>/<slug>.md`
- Reservations: `wiki/dining/reservations.md`
