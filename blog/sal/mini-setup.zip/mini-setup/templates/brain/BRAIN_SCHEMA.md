# Brain schema

Conventions for this vault. The assistant reads this before writing.

- Every page is Markdown. Frontmatter is optional (`tags`, `created`, `updated`).
- Links use Obsidian format: `[[page-name]]`. Every page links to at least one other page.
- `index.md` lists every page, grouped by section, with a one-line description.
- `log.md` is append-only: `## [YYYY-MM-DD | operation] Title` plus one line. Operations:
  create, update, ingest, lint.
- Preference pages end with a `## Change log` of dated lines. The latest word wins: replace
  what's superseded instead of keeping both.
- `raw/` holds untouched source material (pasted articles, exports). Never edit it.

## Layout

- `wiki/personal/`: profile, assistant preferences, task messages
- `wiki/people/`: one page per person
- `wiki/<area>/`: one folder per area of life, each with `<area>-preferences.md`
- `wiki/places/<city>/`: one page per place
- `wiki/lists/`: checkbox lists
- `wiki/projects/`: ongoing projects
