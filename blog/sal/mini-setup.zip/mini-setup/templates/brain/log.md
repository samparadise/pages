# Log

Append-only record of every change to the brain, newest at the bottom.

## [{{TODAY}} | create] Brain created
Set up with the mini-setup walkthrough.
