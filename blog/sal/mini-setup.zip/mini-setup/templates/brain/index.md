# Index

Every page in the brain, with a one-line description. Read this first.

## Personal
- [[wiki/personal/profile]] — Who {{OWNER}} is: home, family, basics
- [[wiki/personal/assistant-preferences]] — How {{OWNER}} wants {{ASSISTANT}} to work
- [[wiki/personal/task-messages]] — What scheduled tasks recently sent (written by the runner)

## Areas
<!-- One line per area preferences page, e.g.
- [[wiki/dining/dining-preferences]] — Restaurants, bars, what {{OWNER}} likes and doesn't -->

## People

## Places

## Lists

## Projects
