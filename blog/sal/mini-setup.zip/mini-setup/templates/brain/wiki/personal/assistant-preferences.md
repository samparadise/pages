---
tags: [personal, preferences]
---

# How {{OWNER}} wants {{ASSISTANT}} to work

General rules that apply to every area. Area-specific likes and dislikes go on that area's
preferences page. Linked from [[index]].

## Replies

- Short and plain, written for a phone screen.
- Lead with the answer or recommendation, then the reasons.

## Doing things

- Ask before booking, buying, sending, posting, cancelling or deleting.

## Change log

- {{TODAY}}: page created during setup.
