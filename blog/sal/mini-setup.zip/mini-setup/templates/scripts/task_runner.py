#!/usr/bin/env python3
"""
task_runner.py
Run every 15 minutes by launchd. Fires due active tasks from tasks.json, reads the reply
signal (NOTIFY / QUIET / STOP), and sends Telegram messages. Also refreshes TripIt hourly
(if TRIPIT_FEED_URL is set) and once a day checks that Claude can run at all.

Run times live in task_state.json (not in git), so tasks.json only changes when a task does.
"""

import os
import re
import json
import asyncio
import logging
from datetime import datetime, timezone
import httpx

from claude_cli import run_claude, split_message, SCRIPTS_DIR, PROJECT_DIR, BRAIN_DIR, LOG_DIR

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_ALLOWED_USER_ID")
TASKS_FILE = os.path.join(SCRIPTS_DIR, "tasks.json")
STATE_FILE = os.path.join(SCRIPTS_DIR, "task_state.json")
MESSAGES_FILE = os.path.join(BRAIN_DIR, "wiki", "personal", "task-messages.md")
MESSAGES_KEEP = 60
HEALTH_CHECK_HOUR = 8  # local time; first run at or after this hour does the daily check
TRIPIT_EVERY_MINUTES = 60

# Strip a leading "<skill>:" from replies, for whatever skills exist.
_skills = sorted(os.listdir(os.path.join(PROJECT_DIR, "skills"))) if os.path.isdir(
    os.path.join(PROJECT_DIR, "skills")) else []
SKILL_PREFIX = re.compile(rf"^\s*({'|'.join(map(re.escape, _skills)) or 'x^'})\s*:\s*", re.IGNORECASE)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
    filename=os.path.join(LOG_DIR, "task_runner.log"),
)


# ── Files ──────────────────────────────────────────────────────────────────────

def load_tasks() -> dict:
    with open(TASKS_FILE) as f:
        return json.load(f)


def load_state() -> dict:
    try:
        with open(STATE_FILE) as f:
            state = json.load(f)
    except (FileNotFoundError, ValueError):
        state = {}
    state.setdefault("last_run", {})
    return state


def save_state(state: dict):
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(state, f, indent=2)
    os.replace(tmp, STATE_FILE)


def mark_done(task_id: str):
    """Re-read the file first so concurrent edits aren't lost."""
    data = load_tasks()
    for t in data["tasks"]:
        if t["id"] == task_id:
            t["status"] = "done"
    with open(TASKS_FILE, "w") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


# ── Scheduling ─────────────────────────────────────────────────────────────────

DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]


def is_due(task: dict, last_run_str: str | None) -> bool:
    if task.get("status") != "active":
        return False
    now = datetime.now()
    last = datetime.fromisoformat(last_run_str).astimezone().replace(tzinfo=None) if last_run_str else None
    run_on, run_at = task.get("run_on"), task.get("run_at")

    if run_on or run_at:
        if run_on and now.weekday() != DAYS.index(run_on.lower()):
            return False
        if run_at:
            h, m = map(int, run_at.split(":"))
            if now < now.replace(hour=h, minute=m, second=0, microsecond=0):
                return False
        return not (last and last.date() == now.date())

    if last is None:
        return True
    return (now - last).total_seconds() >= (task.get("interval_minutes") or 720) * 60


# ── Telegram ───────────────────────────────────────────────────────────────────

async def send_telegram(text: str):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    async with httpx.AsyncClient() as client:
        for chunk in split_message(text):
            r = await client.post(url, json={"chat_id": CHAT_ID, "text": chunk})
            r.raise_for_status()


async def notify(text: str, what: str):
    try:
        await send_telegram(text)
    except Exception as e:
        logging.error(f"Telegram send failed ({what}): {e}")


MESSAGES_HEADER = (
    "# Task messages\n\n"
    "What scheduled tasks sent on Telegram, newest first, written by task_runner.py. Read this "
    "when a reply to a check-in (\"done\", \"why?\") needs context. "
    f"Only the newest {MESSAGES_KEEP} are kept.\n"
)


def record_message(task: dict, text: str):
    """Save each sent message so the chat session knows what a reply refers to."""
    try:
        try:
            with open(MESSAGES_FILE) as f:
                body = f.read()
        except FileNotFoundError:
            body = ""
        entries = body.split("\n## ")[1:]
        entries.insert(0, f"{datetime.now().strftime('%Y-%m-%d %a %H:%M')} | {task['id']}\n\n{text.strip()}\n")
        out = MESSAGES_HEADER + "".join(f"\n## {e.rstrip()}\n" for e in entries[:MESSAGES_KEEP])
        os.makedirs(os.path.dirname(MESSAGES_FILE), exist_ok=True)
        tmp = MESSAGES_FILE + ".tmp"
        with open(tmp, "w") as f:
            f.write(out)
        os.replace(tmp, MESSAGES_FILE)
    except Exception as e:
        logging.error(f"Couldn't record message for '{task['id']}': {e}")


# ── Runs ───────────────────────────────────────────────────────────────────────

async def run_task(task: dict, state: dict):
    logging.info(f"Running task '{task['id']}'")
    res = await run_claude(f"{task['agent']}: {task['prompt']}")
    state["last_run"][task["id"]] = datetime.now(timezone.utc).isoformat()
    save_state(state)

    for note in res["log_only"]:
        logging.info(f"Task '{task['id']}': {note}")
    if res["problems"]:
        msg = f"⚠️ [{task['description']}]\n\n" + "\n".join(res["problems"])
        await notify(msg, task["id"])
        record_message(task, msg)
    if not res["ok"]:
        return

    output = SKILL_PREFIX.sub("", res["text"], count=1).strip()
    if output.startswith("NOTIFY:"):
        msg = output[len("NOTIFY:"):].strip()
        await notify(msg, task["id"])
        record_message(task, msg)
    elif output.startswith("STOP:"):
        reason = output[len("STOP:"):].strip()
        mark_done(task["id"])
        msg = f"[{task['description']}]\n\nStopped: {reason}"
        await notify(msg, task["id"])
        record_message(task, msg)
    elif output == "QUIET":
        logging.info(f"Task '{task['id']}' quiet")
    else:
        logging.warning(f"Task '{task['id']}' returned unexpected output: {output[:200]}")


async def health_check(state: dict):
    """Once a day, make sure Claude can run at all (e.g. the login token hasn't expired)."""
    now = datetime.now()
    today = now.date().isoformat()
    if state.get("health_checked") == today or now.hour < HEALTH_CHECK_HOUR:
        return
    res = await run_claude("Reply with exactly: ok")
    state["health_checked"] = today
    save_state(state)
    if res["ok"] and res["text"].strip().lower().startswith("ok"):
        logging.info("Health check passed")
        return
    logging.error(f"Health check failed: {res['text'][:300]}")
    await notify(
        "⚠️ Claude on the mini can't run, so the bot and scheduled tasks are failing.\n\n"
        f"{res['text'][:300]}\n\n"
        "If it's a login problem: on the mini, run `claude setup-token`, put the new token in "
        f"{SCRIPTS_DIR}/.env as CLAUDE_CODE_OAUTH_TOKEN, then send /restart.",
        "health check",
    )


async def tripit(state: dict):
    """Refresh the TripIt file about hourly; alert at most once a day if it keeps failing."""
    if not os.getenv("TRIPIT_FEED_URL"):
        return
    import tripit_sync
    last = state.get("tripit_synced")
    if last and (datetime.now(timezone.utc) - datetime.fromisoformat(last)).total_seconds() < TRIPIT_EVERY_MINUTES * 60:
        return
    try:
        status = await asyncio.to_thread(tripit_sync.sync)
    except Exception as e:
        logging.error(f"TripIt sync failed: {type(e).__name__}: {str(e)[:200]}")
        today = datetime.now().date().isoformat()
        if state.get("tripit_alerted") != today:
            state["tripit_alerted"] = today
            save_state(state)
            await notify("⚠️ TripIt sync failed, so trip info may be out of date.\n\n"
                         f"{type(e).__name__}: {str(e)[:200]}\n\n"
                         "If you reset the TripIt calendar feed, put the new URL in .env as TRIPIT_FEED_URL.",
                         "tripit")
        return
    state["tripit_synced"] = datetime.now(timezone.utc).isoformat()
    save_state(state)
    logging.info(status)


async def main():
    state = load_state()
    for task in load_tasks()["tasks"]:
        if not is_due(task, state["last_run"].get(task["id"])):
            continue
        try:
            await run_task(task, state)
        except Exception as e:
            logging.exception(f"Task '{task['id']}' failed: {e}")
    for step in (tripit, health_check):
        try:
            await step(state)
        except Exception as e:
            logging.exception(f"{step.__name__} errored: {e}")


if __name__ == "__main__":
    logging.info("Task runner started")
    asyncio.run(main())
    logging.info("Task runner finished")
