#!/usr/bin/env python3
"""
tripit_sync.py
Downloads the owner's private TripIt calendar feed (TRIPIT_FEED_URL in scripts/.env) and
writes the trips as readable text to ~/mcp/tripit/trips.md, which the assistant can read.
Run by task_runner.py about once an hour; can also be run by hand.

The feed URL is a secret (anyone with it can read the trips), so it lives in .env, the
output lives outside git, and the URL is never logged.
"""

import os
import re
import sys
from datetime import datetime, date, timedelta, timezone
from zoneinfo import ZoneInfo

import httpx
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

OUT_DIR = os.path.expanduser("~/mcp/tripit")
OUT_FILE = os.path.join(OUT_DIR, "trips.md")
KEEP_PAST_DAYS = 14
MAX_DESCRIPTION = 1500


# ── ICS parsing (just enough for TripIt's feed) ────────────────────────────────

def unfold(text: str) -> list[str]:
    lines = []
    for raw in text.replace("\r\n", "\n").split("\n"):
        if raw[:1] in (" ", "\t") and lines:
            lines[-1] += raw[1:]
        else:
            lines.append(raw)
    return lines


def unescape(v: str) -> str:
    return re.sub(r"\\([nN,;\\])", lambda m: "\n" if m.group(1) in "nN" else m.group(1), v)


def parse_events(ics: str) -> list[dict]:
    events, cur = [], None
    for line in unfold(ics):
        if line == "BEGIN:VEVENT":
            cur = {}
        elif line == "END:VEVENT":
            if cur is not None:
                events.append(cur)
            cur = None
        elif cur is not None and ":" in line:
            head, value = line.split(":", 1)
            name, *params = head.split(";")
            cur[name.upper()] = (value, dict(p.split("=", 1) for p in params if "=" in p))
    return events


def parse_when(value: str, params: dict) -> tuple[datetime | date, bool]:
    """Return (local datetime or date, is_all_day)."""
    if params.get("VALUE") == "DATE" or re.fullmatch(r"\d{8}", value):
        return datetime.strptime(value[:8], "%Y%m%d").date(), True
    dt = datetime.strptime(value.rstrip("Z")[:15], "%Y%m%dT%H%M%S")
    if value.endswith("Z"):
        dt = dt.replace(tzinfo=timezone.utc)
    elif "TZID" in params:
        try:
            dt = dt.replace(tzinfo=ZoneInfo(params["TZID"].strip('"')))
        except Exception:
            pass
    return dt, False


def fmt(when, all_day: bool) -> str:
    if all_day:
        return when.strftime("%a %b %-d, %Y")
    if when.tzinfo is timezone.utc:
        when = when.astimezone()  # TripIt often sends UTC; show it in the mini's local time
    zone = when.tzname() if when.tzinfo else ""
    return when.strftime("%a %b %-d, %Y %-I:%M%p").replace("AM", "am").replace("PM", "pm") + (f" {zone}" if zone else "")


def sort_key(when, all_day: bool) -> datetime:
    if all_day:
        return datetime.combine(when, datetime.min.time()).astimezone(timezone.utc)
    return when.astimezone(timezone.utc) if when.tzinfo else when.astimezone().astimezone(timezone.utc)


# ── Output ─────────────────────────────────────────────────────────────────────

def render(events: list[dict]) -> str:
    cutoff = datetime.now(timezone.utc) - timedelta(days=KEEP_PAST_DAYS)
    rows = []
    for e in events:
        if "DTSTART" not in e:
            continue
        start, all_day = parse_when(*e["DTSTART"])
        end = parse_when(*e["DTEND"])[0] if "DTEND" in e else None
        if all_day and end:
            end = end - timedelta(days=1)  # ICS all-day ends are exclusive
        if sort_key(end or start, all_day) < cutoff:
            continue
        rows.append((sort_key(start, all_day), e, start, end, all_day))
    rows.sort(key=lambda r: r[0])

    out = [
        "# TripIt itinerary",
        "",
        f"Synced from TripIt's calendar feed {fmt(datetime.now().astimezone(), False)} (the mini's "
        f"local time). Read-only; covers the past {KEEP_PAST_DAYS} days and everything ahead.",
        "Times show their zone. When TripIt only gives UTC, they're converted to the mini's time.",
        "",
    ]
    if not rows:
        out.append("No upcoming trips in TripIt.")
    for _, e, start, end, all_day in rows:
        title = unescape(e.get("SUMMARY", ("(untitled)", {}))[0])
        when = fmt(start, all_day)
        if end and end != start:
            when += f" to {fmt(end, all_day)}"
        out += [f"## {title}", f"When: {when}"]
        if "LOCATION" in e and e["LOCATION"][0].strip():
            out.append(f"Where: {unescape(e['LOCATION'][0])}")
        desc = unescape(e.get("DESCRIPTION", ("", {}))[0]).strip()
        if desc:
            if len(desc) > MAX_DESCRIPTION:
                desc = desc[:MAX_DESCRIPTION] + " …"
            out += ["", desc]
        out.append("")
    return "\n".join(out).rstrip() + "\n"


def sync() -> str:
    """Fetch and write the itinerary. Returns a short status line; raises on failure."""
    url = os.getenv("TRIPIT_FEED_URL", "").strip()
    if not url:
        raise RuntimeError("TRIPIT_FEED_URL isn't set in scripts/.env")
    if url.startswith("webcal://"):
        url = "https://" + url[len("webcal://"):]
    r = httpx.get(url, timeout=30, follow_redirects=True)
    r.raise_for_status()
    if "BEGIN:VCALENDAR" not in r.text:
        raise RuntimeError("TripIt didn't return a calendar (the feed URL may have been reset)")
    events = parse_events(r.text)
    os.makedirs(OUT_DIR, mode=0o700, exist_ok=True)
    tmp = OUT_FILE + ".tmp"
    with open(tmp, "w") as f:
        f.write(render(events))
    os.chmod(tmp, 0o600)
    os.replace(tmp, OUT_FILE)
    return f"TripIt synced: {len(events)} events in feed"


if __name__ == "__main__":
    if len(sys.argv) > 1:  # local test: tripit_sync.py file.ics
        print(render(parse_events(open(sys.argv[1]).read())))
    else:
        print(sync())
