"""
telegram_bot.py
Telegram front end for Claude on the mini. The chat is one ongoing Claude session (resumed
with --resume), so follow-ups work. A new session starts after IDLE_HOURS of quiet or /new.
Only TELEGRAM_ALLOWED_USER_ID is answered.

Commands: /new  /status  /undo  /restart  /help
"""

import os
import json
import uuid
import asyncio
import logging
import subprocess
from logging.handlers import RotatingFileHandler
from datetime import datetime, timezone, timedelta
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

from claude_cli import run_claude, split_message, REPO_DIR, SCRIPTS_DIR, LOG_DIR

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
ALLOWED_USER_ID = int(os.getenv("TELEGRAM_ALLOWED_USER_ID"))
BOT_LABEL = os.getenv("BOT_LABEL", "com.assistant") + ".telegrambot"
SESSION_FILE = os.path.join(SCRIPTS_DIR, "session.json")
TASKS_FILE = os.path.join(SCRIPTS_DIR, "tasks.json")
TASK_STATE_FILE = os.path.join(SCRIPTS_DIR, "task_state.json")

IDLE_HOURS = 2
BOT_STARTED = datetime.now(timezone.utc)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
    handlers=[RotatingFileHandler(os.path.join(LOG_DIR, "telegram_bot.log"),
                                  maxBytes=5_000_000, backupCount=3)],
)
# httpx logs every polling request at INFO, with the bot token in the URL
logging.getLogger("httpx").setLevel(logging.WARNING)

# One Claude turn at a time: two turns resuming the same session at once would collide.
claude_lock = asyncio.Lock()


# ── Session ────────────────────────────────────────────────────────────────────

def load_session() -> dict | None:
    try:
        with open(SESSION_FILE) as f:
            s = json.load(f)
    except (FileNotFoundError, ValueError):
        return None
    if datetime.now(timezone.utc) - datetime.fromisoformat(s["last_used"]) > timedelta(hours=IDLE_HOURS):
        logging.info("Session idle too long; starting a new one")
        return None
    return s


def save_session(session_id: str, started: str | None):
    now = datetime.now(timezone.utc).isoformat()
    with open(SESSION_FILE, "w") as f:
        json.dump({"id": session_id, "started": started or now, "last_used": now}, f, indent=2)


def clear_session():
    try:
        os.remove(SESSION_FILE)
    except FileNotFoundError:
        pass


# ── Helpers ────────────────────────────────────────────────────────────────────

def allowed(update: Update) -> bool:
    user = update.effective_user
    if not user or user.id != ALLOWED_USER_ID:
        logging.warning(f"Rejected update from user {user.id if user else 'unknown'}")
        return False
    return True


def stale(update: Update) -> bool:
    """True for commands sent before this process started (avoids a /restart loop)."""
    return update.message.date < BOT_STARTED


async def reply(update: Update, text: str):
    for chunk in split_message(text):
        await update.message.reply_text(chunk)


def git(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(["git", *args], cwd=REPO_DIR, capture_output=True, text=True)


def ago(iso: str | None) -> str:
    if not iso:
        return "never"
    then = datetime.fromisoformat(iso).astimezone()
    mins = int((datetime.now().astimezone() - then).total_seconds() // 60)
    if mins < 60:
        return f"{mins}m ago"
    if mins < 48 * 60:
        return f"{mins // 60}h ago"
    return then.strftime("%b %-d")


def describe_schedule(t: dict) -> str:
    run_on, run_at = t.get("run_on"), t.get("run_at")
    if run_on or run_at:
        day = f"{run_on.capitalize()}s" if run_on else "Daily"
        if run_at:
            h, m = map(int, run_at.split(":"))
            return f"{day} {datetime(2000, 1, 1, h, m).strftime('%-I:%M%p').lower()}"
        return day
    mins = t.get("interval_minutes") or 720
    return f"every {mins // 60}h" if mins % 60 == 0 else f"every {mins}m"


# ── Claude turns ───────────────────────────────────────────────────────────────

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return
    message = update.message.text
    logging.info(f"Received: {message[:200]}")
    queued = claude_lock.locked()
    asyncio.create_task(run_and_reply(message, update))
    try:
        await update.message.reply_text("⏳ queued, I'll start once the current request finishes..."
                                         if queued else "⏳ working...")
    except Exception as e:
        logging.warning(f"Couldn't send the status note: {e}")


async def run_and_reply(message: str, update: Update):
    async with claude_lock:
        session = load_session()
        try:
            if session:
                res = await run_claude(message, ["--resume", session["id"]])
                if res["missing_session"]:
                    logging.warning(f"Session {session['id']} not found; starting a new one")
                    session = None
            if not session:
                new_id = str(uuid.uuid4())
                res = await run_claude(message, ["--session-id", new_id])
                res["session_id"] = res["session_id"] or new_id
        except Exception as e:
            logging.exception("Claude run failed")
            await update.message.reply_text(f"❌ Error: {e}")
            return
        if res["session_id"]:
            save_session(res["session_id"], session["started"] if session else None)

    for note in res["log_only"]:
        logging.info(note)
    text = res["text"] if res["ok"] else ""
    if res["problems"]:
        logging.warning(f"Problems: {res['problems']}")
        text = (text + "\n\n" if text else "") + "⚠️ " + "\n⚠️ ".join(res["problems"])
    await reply(update, text)
    logging.info(f"Replied ({len(text)} chars), session {res['session_id']}")


# ── Commands ───────────────────────────────────────────────────────────────────

async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return
    await update.message.reply_text(
        f"Just message me. I keep the conversation going until it's been quiet for {IDLE_HOURS}h.\n\n"
        "/new: start a fresh conversation\n"
        "/status: tasks, last runs, conversation, last change\n"
        "/undo: revert the last change I committed (asks first)\n"
        "/restart: restart the bot"
    )


async def cmd_new(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return
    clear_session()
    await update.message.reply_text("🆕 Fresh conversation. What's up?")


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return
    lines = []
    try:
        with open(TASKS_FILE) as f:
            tasks = json.load(f)["tasks"]
        try:
            with open(TASK_STATE_FILE) as f:
                last_runs = json.load(f).get("last_run", {})
        except (FileNotFoundError, ValueError):
            last_runs = {}
        for status, label in (("active", "Active tasks"), ("paused", "Paused")):
            group = [t for t in tasks if t.get("status") == status]
            if group:
                lines.append(f"{label}:")
                for t in group:
                    lines.append(f"• {t['description']} ({t['agent']}, {describe_schedule(t)}, "
                                 f"last ran {ago(last_runs.get(t['id']))})")
                lines.append("")
    except Exception as e:
        lines.append(f"Couldn't read tasks: {e}\n")

    s = load_session()
    lines.append(f"Conversation: started {ago(s['started'])}, last message {ago(s['last_used'])}"
                 if s else "Conversation: none open (next message starts one)")
    lines.append(f"Bot up since {ago(BOT_STARTED.isoformat())}")
    last = git("log", "-1", "--format=%h %s (%cr)")
    if last.returncode == 0:
        lines.append(f"Last change: {last.stdout.strip()[:200]}")
    await reply(update, "\n".join(lines))


async def cmd_undo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update) or stale(update):
        return
    last = git("log", "-1", "--format=%h %s")
    if last.returncode != 0:
        await update.message.reply_text(f"❌ git log failed: {last.stderr.strip()[:300]}")
        return
    if not context.args or context.args[0].lower() != "yes":
        await update.message.reply_text(
            f"The last change is:\n{last.stdout.strip()[:300]}\n\nSend /undo yes to revert it.")
        return
    async with claude_lock:
        res = git("revert", "--no-edit", "HEAD")
    if res.returncode == 0:
        await update.message.reply_text(f"↩️ Reverted:\n{last.stdout.strip()[:300]}")
    else:
        git("revert", "--abort")
        await update.message.reply_text(f"❌ Couldn't revert: {(res.stderr or res.stdout).strip()[:300]}")


async def cmd_restart(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update) or stale(update):
        return
    await update.message.reply_text("🔄 Restarting...")
    logging.info("Restart requested")
    await asyncio.sleep(3)  # let polling acknowledge this update, then launchd restarts us
    subprocess.Popen(["launchctl", "kickstart", "-k", f"gui/{os.getuid()}/{BOT_LABEL}"],
                     start_new_session=True)


async def on_startup(app):
    try:
        await app.bot.send_message(ALLOWED_USER_ID, "✅ Bot is back up.")
    except Exception as e:
        logging.warning(f"Startup message failed: {e}")


def main():
    app = ApplicationBuilder().token(TOKEN).post_init(on_startup).build()
    app.add_handler(CommandHandler(["help", "start"], cmd_help))
    app.add_handler(CommandHandler("new", cmd_new))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("undo", cmd_undo))
    app.add_handler(CommandHandler("restart", cmd_restart))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    logging.info("Bot started")
    app.run_polling()


if __name__ == "__main__":
    main()
