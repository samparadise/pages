"""
claude_cli.py
Shared helpers for telegram_bot.py and task_runner.py: run the Claude CLI headless in the
project folder and split long replies into Telegram-sized messages.

Layout this expects (all paths derived from this file's location):
  ~/assistant/              git repo (REPO_DIR)
  ~/assistant/scripts/      this file, the bot, the runner, .env (SCRIPTS_DIR)
  ~/assistant/project/      CLAUDE.md, skills/, .claude/settings.json (PROJECT_DIR)
"""

import os
import json
import shutil
import asyncio
from dotenv import load_dotenv

SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_DIR = os.path.dirname(SCRIPTS_DIR)
load_dotenv(os.path.join(SCRIPTS_DIR, ".env"))

PROJECT_DIR = os.getenv("PROJECT_DIR") or os.path.join(REPO_DIR, "project")
BRAIN_DIR = os.path.expanduser(os.getenv("BRAIN_DIR") or "~/Documents/brain")
LOG_DIR = os.path.join(SCRIPTS_DIR, "logs")
CLAUDE_BIN = (os.getenv("CLAUDE_BIN") or shutil.which("claude")
              or os.path.expanduser("~/.local/bin/claude"))
# Folders outside the project that Claude may work in (the brain lives in one).
EXTRA_DIRS = [d for d in {os.path.dirname(BRAIN_DIR)} if d]

TELEGRAM_LIMIT = 4000  # Telegram's hard limit is 4096; leave room for a part marker

os.makedirs(LOG_DIR, exist_ok=True)

# Permission refusals are logged, not sent to the owner. Most are routine (Claude tries a shell
# command and falls back to Read/Edit) or the guardrails working as designed. When a refusal
# means a request couldn't be done, Claude says so in its reply.


async def run_claude(prompt: str, session_args: list[str] | None = None) -> dict:
    """Run one headless Claude turn.

    Returns {"text", "session_id", "problems", "log_only", "ok", "missing_session"}.
    """
    proc = await asyncio.create_subprocess_exec(
        CLAUDE_BIN, "-p", prompt,
        *[a for d in EXTRA_DIRS for a in ("--add-dir", d)],
        "--output-format", "json",
        *(session_args or []),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=PROJECT_DIR,
        env=os.environ.copy(),  # includes CLAUDE_CODE_OAUTH_TOKEN from .env
    )
    stdout, stderr = await proc.communicate()
    raw = stdout.decode().strip()
    err = stderr.decode().strip()

    try:
        result = json.loads(raw)
    except ValueError:
        # Not JSON means Claude didn't run at all (expired login, unknown session, crash...)
        text = raw or err or f"claude exited with code {proc.returncode}"
        return {
            "text": text,
            "session_id": None,
            "problems": [f"Claude didn't run normally: {text[:300]}"],
            "log_only": [],
            "ok": False,
            "missing_session": "No conversation found" in text,
        }

    denied = [d.get("tool_name", "unknown tool") for d in result.get("permission_denials", [])]
    problems, log_only = [], []
    if denied:
        log_only.append(f"Permission refused for: {_counts(denied)}")
    if result.get("is_error"):
        problems.append(f"Claude reported an error: {str(result.get('result', ''))[:300]}")

    return {
        "text": str(result.get("result") or "").strip(),
        "session_id": result.get("session_id"),
        "problems": problems,
        "log_only": log_only,
        "ok": not result.get("is_error"),
        "missing_session": False,
    }


def _counts(names: list[str]) -> str:
    return ", ".join(
        f"{n} ({names.count(n)}x)" if names.count(n) > 1 else n
        for n in dict.fromkeys(names)
    )


def split_message(text: str, limit: int = TELEGRAM_LIMIT) -> list[str]:
    """Split text into chunks under `limit`, preferring paragraph, then line, then word breaks."""
    text = text.strip() or "✅ Done (no output)"
    chunks = []
    while len(text) > limit:
        cut = -1
        for sep in ("\n\n", "\n", " "):
            cut = text.rfind(sep, 0, limit)
            if cut > limit // 2:
                break
        if cut <= 0:
            cut = limit
        chunks.append(text[:cut].rstrip())
        text = text[cut:].lstrip()
    chunks.append(text)
    if len(chunks) > 1:
        chunks = [f"{c}\n\n({i}/{len(chunks)})" for i, c in enumerate(chunks, 1)]
    return chunks
